package com.example.stepcountcmu

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*
import kotlin.collections.ArrayDeque

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null

    private var stepCount = mutableStateOf(0)
    private var sensorData = mutableStateOf("X: 0.0\nY: 0.0\nZ: 0.0")
    private var filteredMagnitude = mutableStateOf(0f)
    private var fftMagnitude = mutableStateOf(0f)

    private val windowSize = 5
    private val magnitudeWindow = ArrayDeque<Float>()

    private var lastMagnitude = 0f
    private var lastStepTime = 0L
    private val peakThreshold = 15.0f
    private val stepDelay = 300

    private var startTime = SystemClock.elapsedRealtime()
    private var elapsedTime = mutableStateOf("0m 0s")
    private var distanceKm = mutableStateOf(0f)
    private var kcalBurned = mutableStateOf(0f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        Toast.makeText(
            this,
            "Please hold the phone in your hand in a stable upright position for accurate step counting.",
            Toast.LENGTH_LONG
        ).show()

        setContent {
            MaterialTheme {
                SmartWatchStepCounterUI(
                    stepCount.value,
                    sensorData.value,
                    filteredMagnitude.value,
                    fftMagnitude.value,
                    distanceKm.value,
                    kcalBurned.value,
                    elapsedTime.value
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        sensorData.value = "X: %.2f\nY: %.2f\nZ: %.2f".format(x, y, z)

        val mag = sqrt(x * x + y * y + z * z)

        if (magnitudeWindow.size >= windowSize) {
            magnitudeWindow.removeFirst()
        }
        magnitudeWindow.addLast(mag)

        val meanMag = magnitudeWindow.average().toFloat()
        filteredMagnitude.value = meanMag

        val currentTime = System.currentTimeMillis()
        if (meanMag > peakThreshold && lastMagnitude <= peakThreshold) {
            if (currentTime - lastStepTime > stepDelay) {
                stepCount.value += 1
                lastStepTime = currentTime

                val steps = stepCount.value
                distanceKm.value = steps * 0.0008f           // 0.8 meters per step
                kcalBurned.value = steps * 0.04f             // 0.04 kcal per step
                val elapsedMillis = SystemClock.elapsedRealtime() - startTime
                val minutes = (elapsedMillis / 1000) / 60
                val seconds = (elapsedMillis / 1000) % 60
                elapsedTime.value = "${minutes}m ${seconds}s"
            }
        }

        lastMagnitude = meanMag
        fftMagnitude.value = calculateDominantFrequency(magnitudeWindow.toList())
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun calculateDominantFrequency(data: List<Float>): Float {
        if (data.isEmpty()) return 0f

        val n = data.size
        val real = DoubleArray(n)
        val imag = DoubleArray(n)

        for (k in 0 until n) {
            var sumReal = 0.0
            var sumImag = 0.0
            for (t in 0 until n) {
                val angle = 2.0 * Math.PI * k * t / n
                sumReal += data[t] * cos(angle)
                sumImag -= data[t] * sin(angle)
            }
            real[k] = sumReal
            imag[k] = sumImag
        }

        var maxMag = 0.0
        var maxIndex = 1
        for (i in 1 until n / 2) {
            val mag = sqrt(real[i] * real[i] + imag[i] * imag[i])
            if (mag > maxMag) {
                maxMag = mag
                maxIndex = i
            }
        }

        val samplingRate = 50f
        return maxIndex * samplingRate / n
    }
}

@Composable
fun SmartWatchStepCounterUI(
    stepCount: Int,
    rawSensorData: String,
    filteredMag: Float,
    dominantFreq: Float,
    distanceKm: Float,
    kcalBurned: Float,
    elapsedTime: String
) {
    val walkingAnimationProgress = rememberInfiniteTransition()
    val offsetAnim by walkingAnimationProgress.animateFloat(
        initialValue = 0f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101010)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .padding(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF202020))
                .padding(32.dp)
                .width(300.dp)
        ) {
            Text(
                "Step Counter",
                color = Color(0xFF00FFC8),
                fontSize = 28.sp,
                modifier = Modifier.padding(bottom = 24.dp)
            )
            Text(
                "$stepCount",
                color = Color(0xFF00FFC8),
                fontSize = 64.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Added the three new Text items here:
            Text(
                "Distance: %.2f km".format(distanceKm),
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                "Calories Burned: %.1f kcal".format(kcalBurned),
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                "Time Elapsed: $elapsedTime",
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Animated person
            Canvas(modifier = Modifier.size(80.dp).padding(bottom = 24.dp)) {
                val centerX = size.width / 2
                val centerY = size.height / 2 + offsetAnim
                drawCircle(Color(0xFF00FFC8), 15f, center = androidx.compose.ui.geometry.Offset(centerX, centerY))
                drawCircle(Color(0xFF00FFC8), 8f, center = androidx.compose.ui.geometry.Offset(centerX, centerY - 30f))
                val legLength = 20f
                val legOffset = offsetAnim / 2
                drawLine(
                    Color(0xFF00FFC8),
                    androidx.compose.ui.geometry.Offset(centerX, centerY + 15f),
                    androidx.compose.ui.geometry.Offset(centerX - legLength + legOffset, centerY + 35f),
                    strokeWidth = 4f, cap = StrokeCap.Round
                )
                drawLine(
                    Color(0xFF00FFC8),
                    androidx.compose.ui.geometry.Offset(centerX, centerY + 15f),
                    androidx.compose.ui.geometry.Offset(centerX + legLength - legOffset, centerY + 35f),
                    strokeWidth = 4f, cap = StrokeCap.Round
                )
            }

            Text(
                "Raw Acceleration:\n$rawSensorData",
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            Text(
                "Filtered Magnitude: %.2f".format(filteredMag),
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                "Dominant Frequency: %.1f Hz".format(dominantFreq),
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

